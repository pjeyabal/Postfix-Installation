package com.example.pandiyarajan.barcodescanning;

import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import android.app.Activity;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.content.Intent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.util.HashMap;


public class MainActivity extends Activity implements OnClickListener {

    private ImageButton scanBtn;
    private TextView formatTxt, successTxt;
    private String locationId,formatId;
    private static HashMap<String,String> mapCoordinates = new HashMap<String,String>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        scanBtn = (ImageButton)findViewById(R.id.scan_button);
        //formatTxt = (TextView)findViewById(R.id.scan_format);
        //successTxt = (TextView)findViewById(R.id.successMessage);
        scanBtn.setVisibility(View.VISIBLE);
        scanBtn.setOnClickListener(this);
        ImageView imgView = (ImageView)findViewById(R.id.imageMap);
        imgView.setVisibility(View.INVISIBLE);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClick(View v){
        if(v.getId()==R.id.scan_button){
            IntentIntegrator scanIntegrator = new IntentIntegrator(this);
            scanIntegrator.initiateScan();
        }
    }

    public void onActivityResult(int requestCode, int resultCode, Intent intent) {
        IntentResult scanningResult = IntentIntegrator.parseActivityResult(requestCode, resultCode, intent);
        if (scanningResult != null) {
            locationId = scanningResult.getContents();
            formatId = scanningResult.getFormatName();
            Toast toast = Toast.makeText(getApplicationContext(),
                   locationId , Toast.LENGTH_SHORT);
            //toast.show();
             //successTxt.setText("                      Checked in Successfully!");
            //formatTxt.setText("FORMAT: " + scanFormat);
            //contentTxt.setText("CONTENT: " + scanContent);
           AssetManager assetMgr = this.getAssets();
           setImage(assetMgr,locationId);
        }
        else{
            Toast toast = Toast.makeText(getApplicationContext(),
                    "No scan data received!", Toast.LENGTH_SHORT);
            toast.show();
        }
    }

    public void setImage(AssetManager manager,String locId){
        try {
            InputStream open = null;
            open = manager.open("floorplan.png");
            formMap();
            Bitmap bitmapOne = BitmapFactory.decodeStream(open);
            open = manager.open("pin.png");
            Bitmap bitmapTwo = BitmapFactory.decodeStream(open);
            ImageView imgView = (ImageView)findViewById(R.id.imageMap);
            ImageButton imgButton = (ImageButton)findViewById(R.id.scan_button);
            imgButton.setVisibility(View.INVISIBLE);
            imgButton = (ImageButton)findViewById(R.id.customlocation);
            imgButton.setVisibility(View.INVISIBLE);
            ImageView imgViewHeader = (ImageView)findViewById(R.id.header);
            //imgViewHeader.setVisibility(View.INVISIBLE);

            imgView.setImageBitmap(overlay(bitmapOne, bitmapTwo,locId));
            imgView.setVisibility(View.VISIBLE);

            Toast toast =Toast.makeText(MainActivity.this, "Successfully Checked in 1S!!", Toast.LENGTH_SHORT);
            toast.setGravity(Gravity.CENTER, 0, 0);
            toast.show();
        }
        catch(Exception e){
            Intent intent = new Intent(getApplicationContext(), Homepage.class);
            startActivity(intent);
            Log.e("Image Processing","error while merging the error");
        }
    }

    public static Bitmap overlay(Bitmap bmp1, Bitmap bmp2,String locId) {
        Bitmap bmOverlay = Bitmap.createBitmap(bmp1.getWidth(), bmp1.getHeight(), bmp1.getConfig());
        Canvas canvas = new Canvas(bmOverlay);
        int x = Integer.parseInt(getCoordinates(locId).split("-")[0]);
        int y = Integer.parseInt(getCoordinates(locId).split("-")[1]);
        canvas.drawBitmap(bmp1, new Matrix(), null);
        canvas.drawBitmap(bmp2, x, y, null);
        return bmOverlay;
    }

    public void onClickcustom(View view){
        Intent intent = new Intent(getApplicationContext(), CustomLocation.class);
        startActivity(intent);
    }

    public void formMap(){
        mapCoordinates.put("/IL/RW/01/01/SS/AE04/","730-300");
        mapCoordinates.put("/IL/RW/01/01/SS/AL34/","700-800");
        mapCoordinates.put("/IL/RW/01/01/SS/BK35/","700-900");
    }

    public static String getCoordinates(String key){
        return mapCoordinates.get(key);
    }
}
