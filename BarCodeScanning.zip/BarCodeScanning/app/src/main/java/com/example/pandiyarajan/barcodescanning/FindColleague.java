package com.example.pandiyarajan.barcodescanning;

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.media.Image;
import android.os.Bundle;
import android.util.Log;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import org.w3c.dom.Text;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;


public class FindColleague extends Activity {

    private ImageButton searchButton;
    private TextView showName;
    EditText mEdit;
    private String lastName="";
   // TextView successMsg;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_findcolleague);
        searchButton=(ImageButton)findViewById(R.id.search);
        ImageView imageView=(ImageView)findViewById(R.id.mapSearch);
        imageView.setVisibility(View.INVISIBLE);
        mEdit= (EditText)findViewById(R.id.nameSearch);
        showName=(TextView) findViewById(R.id.showname);
        showName.setVisibility(View.INVISIBLE);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_homepage, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClickSearch(View v)throws Exception{
        //successMsg=(TextView)findViewById(R.id.successMessage);
        InputStream open=null;
        String line,lname=mEdit.getText().toString();
        lastName=lname;
        int x=0,y=0;
        AssetManager assetMgr = this.getAssets();
        open = assetMgr.open("mapping.txt");
        InputStreamReader ipsr=new InputStreamReader(open);
        BufferedReader br=new BufferedReader(ipsr);
        while((line=br.readLine())!=null){

            if(line.split(" ")[0].equals(lname)) {
                x = Integer.parseInt(line.split(" ")[1]);
                y = Integer.parseInt(line.split(" ")[2]);
            }
        }
        setImage(assetMgr,x,y);
    }

    public void setImage(AssetManager manager,int x,int y){
        InputStream open = null;
        showName=(TextView) findViewById(R.id.showname);
        try {
            if(x!=0 && y!=0) {
                open = manager.open("floorplan.png");
                Bitmap bitmapOne = BitmapFactory.decodeStream(open);
                open = manager.open("pin.png");
                Bitmap bitmapTwo = BitmapFactory.decodeStream(open);
                ImageView imgView = (ImageView) findViewById(R.id.mapSearch);
                EditText search = (EditText) findViewById(R.id.nameSearch);
                search.setVisibility(View.INVISIBLE);
                ImageButton btnSearch = (ImageButton) findViewById(R.id.search);
                btnSearch.setVisibility(View.INVISIBLE);
                imgView.setImageBitmap(overlay(bitmapOne, bitmapTwo, x, y));
                imgView.setVisibility(View.VISIBLE);
                Toast toast = Toast.makeText(FindColleague.this, "Colleague location found!!!", Toast.LENGTH_SHORT);
                toast.setGravity(Gravity.CENTER, 0, 0);
                toast.show();
                showName.setText(lastName);
                showName.setVisibility(View.VISIBLE);
            }
            else{
                ImageView imgView = (ImageView) findViewById(R.id.mapSearch);
                open = manager.open("noresults.png");
                imgView.setImageResource(R.drawable.noresults);
                imgView.setVisibility(View.VISIBLE);
                showName.setText(lastName);
                showName.setVisibility(View.VISIBLE);
                EditText search = (EditText) findViewById(R.id.nameSearch);
                search.setVisibility(View.INVISIBLE);
                ImageButton btnSearch = (ImageButton) findViewById(R.id.search);
                btnSearch.setVisibility(View.INVISIBLE);
            }
        }
        catch(Exception e){
            Log.e("Image Processing", "error while merging the error");
        }
    }

    public static Bitmap overlay(Bitmap bmp1, Bitmap bmp2,int x,int y) {
        Bitmap bmOverlay = Bitmap.createBitmap(bmp1.getWidth(), bmp1.getHeight(), bmp1.getConfig());
        Canvas canvas = new Canvas(bmOverlay);
        canvas.drawBitmap(bmp1, new Matrix(), null);
        canvas.drawBitmap(bmp2, x, y, null);
        return bmOverlay;
    }

}
